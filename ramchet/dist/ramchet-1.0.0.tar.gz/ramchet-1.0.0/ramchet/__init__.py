#!/usr/bin/python
#-*- coding:utf-8 -*-

#############################################
# File Name: __init__.py
# Author: xiaoh
# Mail: xiaoh@about.me 
# Created Time:  2016-01-30 15:37:47
#############################################

__version__ = '1.0.0'
